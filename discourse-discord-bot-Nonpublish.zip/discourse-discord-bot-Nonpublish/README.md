# discourse-discord-bot
A Discord bot that runs on your Discourse server to link the two servers.

[Read more about this project, a Discourse plugin, here](https://meta.discourse.org/t/discord-bot-run-one-on-your-discourse-server-keep-things-in-sync/122530)
